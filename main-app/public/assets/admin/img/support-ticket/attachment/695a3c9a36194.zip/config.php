<?php
// Local config. Do NOT commit this to source control.
return [

    // ------------------------------------------------------------
    // General
    // ------------------------------------------------------------
    'PUBLIC_API_BASE'        => 'https://tbdb.store/api',


    // ------------------------------------------------------------
    // Authorize.Net
    // ------------------------------------------------------------
    'AUTHORIZE_LOGIN_ID'     => '9a9Mg4sF6YBH',
    'AUTHORIZE_TRANSACTION_KEY' => '768844FGveh6nnBH',
    'AUTHORIZE_ENV'          => 'sandbox', // 'sandbox' or 'production'


    // ------------------------------------------------------------
    // Stripe
    // ------------------------------------------------------------
    'STRIPE_SECRET_KEY'      => 'sk_test_51RvWLaQXqzpS8lHPaCsZm9sB5Rq7sk925CCaTG3MUVyfTHeJstOcAeczfxLOm4LSbSLZoajQf1XiOyj4rXimvjUC0053IPoMGQ',


    // ------------------------------------------------------------
    // Midtrans
    // ------------------------------------------------------------
    'MIDTRANS_SERVER_KEY'    => 'Mid-server-kYh-OLCuIYxP4mxxQlf22PBE', 


    // ------------------------------------------------------------
    // Mollie
    // ------------------------------------------------------------
    'MOLLIE_API_KEY'         => 'test_rs2yREv2jn7jaxP7d7S5pq8Jtvmkgq', // test_ for sandbox, live_ for production


    // ------------------------------------------------------------
    // MyFatoorah
    // ------------------------------------------------------------
    'MYFATOORAH_API_KEY'     => 'rLtt6JWvbUHDDhsZnfpAhpYk4dxYDQkbcPTyGaKp2TYqQgG7FGZ5Th_WD53Oq8Ebz6A53njUoo1w3pjU1D4vs_ZMqFiz_j0urb_BH9Oq9VZoKFoJEDAbRZepGcQanImyYrry7Kt6MnMdgfG5jn4HngWoRdKduNNyP4kzcp3mRv7x00ahkm9LAK7ZRieg7k1PDAnBIOG3EyVSJ5kK4WLMvYr7sCwHbHcu4A5WwelxYK0GMJy37bNAarSJDFQsJ2ZvJjvMDmfWwDVFEVe_5tOomfVNt6bOg9mexbGjMrnHBnKnZR1vQbBtQieDlQepzTZMuQrSuKn-t5XZM7V6fCW7oP-uXGX-sMOajeX65JOf6XVpk29DP6ro8WTAflCDANC193yof8-f5_EYY-3hXhJj7RBXmizDpneEQDSaSz5sFk0sV5qPcARJ9zGG73vuGFyenjPPmtDtXtpx35A-BVcOSBYVIWe9kndG3nclfefjKEuZ3m4jL9Gg1h2JBvmXSMYiZtp9MR5I6pvbvylU_PP5xJFSjVTIz7IQSjcVGO41npnwIxRXNRxFOdIUHn0tjQ-7LwvEcTXyPsHXcMD8WtgBh-wxR8aKX7WPSsT1O8d8reb2aR7K3rkV3K82K_0OgawImEpwSvp9MNKynEAJQS6ZHe_J_l77652xwPNxMRTMASk1ZsJL', // shortened for readability
    'MYFATOORAH_BASE'        => 'https://apitest.myfatoorah.com', // test base URL


    // ------------------------------------------------------------
    // Xendit
    // ------------------------------------------------------------
    'XENDIT_SECRET_KEY'      => 'xnd_development_UivMX46uUwLNa6kw65TWY8YEMWzZB3py9EJE9JXORtPwjwulQvOl1x9ZL8jA',
    'XENDIT_BASE'            => 'https://api.xendit.co',


    // ------------------------------------------------------------
    // Flutterwave
    // ------------------------------------------------------------
    'FLW_SECRET_KEY'         => 'FLWSECK_TEST-a70237f1ef85c46feb31311de7544e7b-X',
    'FLW_BASE'               => 'https://api.flutterwave.com',


    // ------------------------------------------------------------
    // PayPal (Sandbox)
    // ------------------------------------------------------------
    'PAYPAL_CLIENT_ID'       => 'AQbWYUvDai8Mutu_q5K_EjZDKMKtmMaBr2RqgVldbKWkYyZ5ctcpsigrEE1U32VRSNa9FqEkZ4DctO0C',
    'PAYPAL_SECRET'          => 'EAJQLbbDKsTnbDAjEHKH3UXTjrWjOhzfxNuIHks8NvKs1rSUqbkP0N0GCpYh4DthaNS4x14pGucrlk8v',
    'PAYPAL_BASE'            => 'https://api-m.sandbox.paypal.com', // Live: https://api-m.paypal.com


    // ------------------------------------------------------------
    // PhonePe
    // ------------------------------------------------------------
    'PHONEPE_BASE'           => 'https://api-preprod.phonepe.com/apis/pg-sandbox',
    'PHONEPE_MERCHANT_ID'    => 'PGTESTPAYUAT86',
    'PHONEPE_SALT_KEY'       => '96434309-7796-489d-8924-ab56988a6076',
    'PHONEPE_SALT_INDEX'     => '1',


    // ------------------------------------------------------------
    // Mercado Pago
    // ------------------------------------------------------------
    'MP_ACCESS_TOKEN'        => 'TEST-705032440135962-041006-ad2e021853f22338fe1a4db9f64d1491-421886156',
    'MP_BASE'                => 'https://api.mercadopago.com', // Base API (same for test/live; token decides env)


    // ------------------------------------------------------------
    // Paystack
    // ------------------------------------------------------------
    'PAYSTACK_SECRET_KEY'    => 'sk_test_27651c4fa4ec934e573b52dfee1f1a13988f4cb9', // from dashboard
    'PAYSTACK_BASE'          => 'https://api.paystack.co',


    // ------------------------------------------------------------
    // Toyyibpay
    // ------------------------------------------------------------
    'TOYYIBPAY_BASE'         => 'https://dev.toyyibpay.com',
    'TOYYIBPAY_SECRET_KEY'   => 'vx3lhl91-m1cu-c1m0-jf6m-7nzwqo3dfjat', // from Toyyibpay
    'TOYYIBPAY_CATEGORY_CODE'=> 'o3zjib5i',
    
    // ------------------------------------------------------------
     // Instamojo (v1.1)
    // ------------------------------------------------------------
    'MONNIFY_BASE'          => 'https://sandbox.monnify.com',
    'MONNIFY_API_KEY'       => 'MK_TEST_D0ALT1D5J8',
    'MONNIFY_SECRET_KEY'    => 'NY9TURU60499W3PLC7EUSKDJNW1912A8',
    'MONNIFY_CONTRACT_CODE' => '4147865873',
    
    // ------------------------------------------------------------
    // NOWPayments
    // ------------------------------------------------------------
    'NOWPAYMENTS_API_KEY' => '9N7MHQ6-RF4MSWT-GPMW616-QSKT2V9', // from https://account.nowpayments.io
    'NOWPAYMENTS_BASE'    => 'https://api.nowpayments.io/v1',
    

];
